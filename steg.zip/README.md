Welcome to STEG
The steganography PNG encoder and decoder

You may use this as command line utility

Note: 
<example> are required inputs
[example] are optional

You may either use, std in for your hidden message or .txt file (ASCII ONLY)

Example uses:

steg -e <original image name> <modified image name> [input ASCII text file name\n"
steg -d <modified image name> [output ASCII text file name]\n"



